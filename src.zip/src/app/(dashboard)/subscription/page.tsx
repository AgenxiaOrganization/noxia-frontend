'use client'

import { useState, useEffect, Suspense } from 'react'
import React from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import {
  CreditCard, Check, X, Crown, Star,
  Package, BarChart,
  Headphones, Calendar, Gift, Loader2, Receipt, Download, Trash2, Ban,
} from 'lucide-react'
import { toast } from 'sonner'
import { getMe } from '@/lib/api'
import {
  getMySubscription, subscribeToPlan, getPlans, getFeatureRegistry,
  listMyTransactions, hideTransaction, downloadTransactionInvoicePdf, cancelSubscription,
  type Subscription, type Plan, type FeatureRegistryEntry, type PvitTransaction,
  type BillingPeriod,
} from '@/lib/api/subscription'
import Loader from '@/components/ui/Loader'
import PvitPaymentModal from '@/components/payments/PvitPaymentModal'
import CancelSubscriptionModal from '@/components/subscription/CancelSubscriptionModal'

const featureCategories = [
  { id: 'base', label: 'Fonctionnalités de base', icon: Package },
  { id: 'advanced', label: 'Fonctionnalités avancées', icon: BarChart },
  { id: 'support', label: 'Support & Assistance', icon: Headphones },
]

const statusLabels: Record<string, { label: string; color: string }> = {
  trialing: { label: 'Essai', color: '#3b82f6' },
  active: { label: 'Actif', color: '#22c55e' },
  expired: { label: 'Expiré', color: '#ef4444' },
  canceled: { label: 'Annulé', color: '#64748b' },
}

export default function SubscriptionPage() {
  return (
    <Suspense fallback={<Loader />}>
      <SubscriptionPageContent />
    </Suspense>
  )
}

function SubscriptionPageContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [plans, setPlans] = useState<Plan[]>([])
  const [featureRegistry, setFeatureRegistry] = useState<FeatureRegistryEntry[]>([])
  const [transactions, setTransactions] = useState<PvitTransaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isChangingPlan, setIsChangingPlan] = useState(false)
  const [selectedPlanCode, setSelectedPlanCode] = useState<string | null>(null)
  const [paymentModalPlan, setPaymentModalPlan] = useState<Plan | null>(null)
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod>('monthly')
  const [downloadingRef, setDownloadingRef] = useState<string | null>(null)
  const [hidingRef, setHidingRef] = useState<string | null>(null)
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [isCanceling, setIsCanceling] = useState(false)
  // Company.is_certified (KYB) — determine si un plan `warning` doit
  // declencher un toast d'avertissement post-activation (voir
  // Plan.certification_requirement cote backend).
  const [isCertified, setIsCertified] = useState(false)

  const loadData = () => {
    setIsLoading(true)
    Promise.all([getMySubscription(), getPlans(), getFeatureRegistry(), listMyTransactions(), getMe()])
      .then(([sub, planList, registry, txs, me]) => {
        setSubscription(sub)
        setPlans([...planList].sort((a, b) => a.display_order - b.display_order))
        setFeatureRegistry(registry)
        setTransactions(txs)
        setIsCertified(Boolean(me.company?.is_certified))
      })
      .catch((e) => console.error('Erreur chargement abonnement', e))
      .finally(() => setIsLoading(false))
  }

  useEffect(loadData, [])

  // Retour du formulaire bancaire PVit (paiement carte, voir
  // PvitPaymentModal / MYPVIT_SUCCESS_REDIRECTION_URL_CODE cote backend) —
  // le webhook a deja (ou va) confirmer le statut definitif independamment
  // de cette redirection ; on rafraichit juste l'abonnement pour refleter
  // l'activation si elle a deja eu lieu, et on nettoie l'URL.
  useEffect(() => {
    const payment = searchParams.get('payment')
    if (!payment) return
    if (payment === 'success') {
      toast.success('Paiement en cours de confirmation — votre abonnement sera activé sous quelques instants.')
      loadData()
    } else if (payment === 'failed') {
      toast.error('Le paiement par carte a été refusé ou annulé.')
    }
    router.replace('/subscription')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams])

  const handlePlanChange = async (plan: Plan) => {
    // Plan gratuit (Essai) : pas de paiement reel a faire, on garde
    // l'activation directe existante. Plan payant : ouvre le flux MyPVit
    // (voir PvitPaymentModal) — l'activation n'aura lieu qu'une fois le
    // paiement confirme par webhook cote backend.
    if (plan.is_free || Number(plan.price) === 0) {
      setSelectedPlanCode(plan.code)
      setIsChangingPlan(true)
      try {
        const updated = await subscribeToPlan(plan.code)
        setSubscription(updated)
        toast.success(`Plan ${updated.plan.name} activé.`)
        if (updated.plan.certification_requirement === 'warning' && !isCertified) {
          toast.warning(
            `Le plan ${updated.plan.name} recommande une entreprise certifiée. Faites certifier votre établissement.`,
            { action: { label: 'Certifier mon établissement', onClick: () => router.push('/certification') } },
          )
        }
      } catch (err) {
        console.error(err)
        toast.error(err instanceof Error ? err.message : "Erreur lors de l'activation du plan.")
      } finally {
        setIsChangingPlan(false)
      }
      return
    }
    setPaymentModalPlan(plan)
  }

  const handleDownloadInvoice = async (tx: PvitTransaction) => {
    setDownloadingRef(tx.merchant_reference)
    try {
      await downloadTransactionInvoicePdf(tx.merchant_reference, `facture_abonnement_${tx.merchant_reference}.pdf`)
    } catch (err) {
      console.error(err)
      toast.error(err instanceof Error ? err.message : 'Erreur lors du téléchargement de la facture.')
    } finally {
      setDownloadingRef(null)
    }
  }

  const handleCancelSubscription = async () => {
    setIsCanceling(true)
    try {
      const updated = await cancelSubscription()
      setSubscription(updated)
      setShowCancelModal(false)
      toast.success('Abonnement annulé. Tous les services sont suspendus jusqu\'à la reprise d\'un plan.')
    } catch (err) {
      console.error(err)
      toast.error(err instanceof Error ? err.message : "Erreur lors de l'annulation de l'abonnement.")
    } finally {
      setIsCanceling(false)
    }
  }

  const handleHideTransaction = async (tx: PvitTransaction) => {
    if (!confirm('Retirer cette transaction de votre historique ?')) return
    setHidingRef(tx.merchant_reference)
    try {
      await hideTransaction(tx.merchant_reference)
      setTransactions((prev) => prev.filter((t) => t.merchant_reference !== tx.merchant_reference))
      toast.success('Transaction retirée de votre historique.')
    } catch (err) {
      console.error(err)
      toast.error(err instanceof Error ? err.message : "Erreur lors de la suppression.")
    } finally {
      setHidingRef(null)
    }
  }

  if (isLoading) return <Loader />

  const statusInfo = subscription ? statusLabels[subscription.status] ?? statusLabels.canceled : statusLabels.canceled
  const currentPlanCode = subscription?.plan.code
  const endDate = subscription?.current_period_end ?? subscription?.trial_end

  const registryLabels = featureRegistry.map((f) => f.label)
  const freeLabels = Array.from(
    new Set(plans.flatMap((p) => p.features.filter((f) => !f.key).map((f) => f.label))),
  )
  const allFeatureLabels = Array.from(new Set([...registryLabels, ...freeLabels]))

  // Categorie reelle depuis le registre backend (subscriptions.feature_registry) —
  // plus de mapping par mot-cle duplique et desynchronisable cote frontend.
  // Un label decoratif libre (sans cle) n'a pas de categorie backend : classe
  // en 'support', seule categorie purement decorative restante.
  const featureCategoryOf = (label: string): string =>
    featureRegistry.find((f) => f.label === label)?.category ?? 'support'

  return (
    <div className="p-4 space-y-4">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white">Abonnement</h1>
          <p className="text-sm" style={{ color: '#94a3b8' }}>
            Gérez votre plan
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="text-xs px-3 py-1 rounded-full flex items-center gap-1"
            style={{ background: `${statusInfo.color}20`, color: statusInfo.color }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
            {statusInfo.label}
          </span>
        </div>
      </div>

      {/* PLAN ACTUEL */}
      <div
        className="rounded-xl border p-6"
        style={{
          background: subscription?.status === 'expired'
            ? 'linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(127, 29, 29, 0.15))'
            : 'linear-gradient(135deg, rgba(99, 102, 241, 0.15), rgba(49, 46, 129, 0.15))',
          borderColor: subscription?.status === 'expired' ? '#ef4444' : '#6366f1',
        }}
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5" style={{ color: '#f59e0b' }} />
              <h2 className="text-lg font-bold text-white">Plan {subscription?.plan.name ?? '—'}</h2>
            </div>
            <p className="text-2xl font-bold text-white mt-1">
              {subscription ? Number(subscription.plan.price).toLocaleString('fr-FR') + ' FCFA' : '...'}
              <span className="text-sm font-normal" style={{ color: '#94a3b8' }}>/{subscription?.plan.period_label || 'mois'}</span>
            </p>
            {endDate && (
              <div className="flex items-center gap-4 mt-2 text-sm">
                <span style={{ color: subscription?.status === 'expired' ? '#ef4444' : '#94a3b8' }}>
                  <Calendar className="w-3 h-3 inline mr-1" />
                  {subscription?.status === 'expired' ? 'Expiré le' : subscription?.status === 'trialing' ? "Fin d'essai" : 'Prochain paiement'} :{' '}
                  {new Date(endDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
                </span>
              </div>
            )}
          </div>
          {(subscription?.status === 'active' || subscription?.status === 'trialing') && (
            <button
              onClick={() => setShowCancelModal(true)}
              className="flex items-center gap-1.5 text-xs font-medium transition hover:opacity-80 self-start sm:self-auto"
              style={{ color: '#ef4444' }}
            >
              <Ban className="w-3.5 h-3.5" />
              Annuler mon abonnement
            </button>
          )}
        </div>
      </div>

      {/* PLANS DISPONIBLES */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-2">
        <h3 className="font-semibold text-sm text-white">Changer de plan</h3>
        <div className="flex items-center gap-1 p-1 rounded-lg self-start" style={{ background: 'rgba(51, 65, 85, 0.5)' }}>
          <button
            onClick={() => setBillingPeriod('monthly')}
            className="px-3 py-1.5 rounded-md text-xs font-medium transition"
            style={{
              background: billingPeriod === 'monthly' ? '#4f46e5' : 'transparent',
              color: billingPeriod === 'monthly' ? '#fff' : '#94a3b8',
            }}
          >
            Mensuel
          </button>
          <button
            onClick={() => setBillingPeriod('yearly')}
            className="px-3 py-1.5 rounded-md text-xs font-medium transition"
            style={{
              background: billingPeriod === 'yearly' ? '#4f46e5' : 'transparent',
              color: billingPeriod === 'yearly' ? '#fff' : '#94a3b8',
            }}
          >
            Annuel
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan) => {
          const isCurrent = plan.code === currentPlanCode
          const hasYearlyOffer = plan.yearly_price !== null && Number(plan.yearly_price) >= 0
          const useYearly = billingPeriod === 'yearly' && hasYearlyOffer
          const price = useYearly ? parseFloat(plan.yearly_price as string) : parseFloat(plan.price)
          const isFree = plan.is_free || parseFloat(plan.price) === 0
          const isChanging = selectedPlanCode === plan.code && isChangingPlan
          const planFeatures = plan.features.filter((f) => f.included)
          // Un compte ayant deja beneficie de l'essai gratuit (has_trialed,
          // voir SubscribeSerializer.validate_plan_code cote backend) ne peut
          // plus jamais y re-souscrire — la carte reste visible mais desactivee,
          // le vrai blocage restant applique cote serveur.
          const isTrialUnavailable = isFree && !isCurrent && Boolean(subscription?.has_trialed)

          return (
            <div
              key={plan.code}
              className={`rounded-xl border p-5 transition-all relative ${
                isCurrent ? 'border-primary-500' : isTrialUnavailable ? '' : 'hover:border-primary-500'
              }`}
              style={{
                background: isCurrent
                  ? 'linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(49, 46, 129, 0.1))'
                  : '#1e293b',
                borderColor: isCurrent ? '#6366f1' : '#334155',
                transform: plan.is_featured ? 'translateY(-4px)' : 'none',
                opacity: isTrialUnavailable ? 0.6 : 1,
              }}
            >
              {plan.is_featured && (
                <div
                  className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-white text-xs font-bold"
                  style={{ background: '#6366f1' }}
                >
                  <Star className="w-3 h-3 inline mr-1" />
                  {plan.badge_label || 'Recommandé'}
                </div>
              )}
              {isFree && !plan.is_featured && (
                <div
                  className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-white text-xs font-bold"
                  style={{ background: '#22c55e' }}
                >
                  <Gift className="w-3 h-3 inline mr-1" />
                  {plan.badge_label || 'Essai gratuit'}
                </div>
              )}
              <h3 className="text-lg font-bold text-white">{plan.name}</h3>
              <p className="text-sm" style={{ color: '#94a3b8' }}>{plan.description}</p>
              <div className="my-3">
                {plan.has_active_discount && plan.original_price && (
                  <div className="text-sm line-through mb-0.5" style={{ color: '#64748b' }}>
                    {parseFloat(plan.original_price).toLocaleString('fr-FR')} FCFA
                  </div>
                )}
                <span className={`text-3xl font-bold ${isFree ? 'text-green-400' : 'text-white'}`}>
                  {price === 0 ? 'Gratuit' : price.toLocaleString('fr-FR') + ' FCFA'}
                </span>
                {price > 0 && (
                  <span className="text-sm" style={{ color: '#94a3b8' }}>/{useYearly ? 'an' : plan.period_label}</span>
                )}
                {useYearly && plan.yearly_discount_percent > 0 && (
                  <p className="text-xs mt-1 font-medium" style={{ color: '#818cf8' }}>
                    Économisez {plan.yearly_discount_percent}% vs mensuel
                  </p>
                )}
                {!isFree && billingPeriod === 'yearly' && !hasYearlyOffer && (
                  <p className="text-xs mt-1" style={{ color: '#64748b' }}>Pas d'offre annuelle — facturé au mois</p>
                )}
                {isFree && plan.trial_days > 0 && (
                  <p className="text-xs mt-1" style={{ color: '#22c55e' }}>{plan.trial_days} jours d'essai complet</p>
                )}
              </div>

              <ul className="space-y-1.5 mb-4 text-xs">
                {planFeatures.slice(0, 4).map((feature, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Check className="w-3 h-3" style={{ color: '#22c55e' }} />
                    <span style={{ color: '#cbd5e1' }}>{feature.label}</span>
                  </li>
                ))}
                {planFeatures.length > 4 && (
                  <li className="text-xs" style={{ color: '#64748b' }}>
                    +{planFeatures.length - 4} autres fonctionnalités
                  </li>
                )}
              </ul>

              {isTrialUnavailable ? (
                <p
                  className="w-full py-2 rounded-lg text-xs text-center font-medium"
                  style={{ background: 'rgba(148, 163, 184, 0.1)', color: '#94a3b8' }}
                >
                  Essai déjà utilisé — choisissez un plan payant
                </p>
              ) : (
                <button
                  onClick={() => handlePlanChange(plan)}
                  disabled={isCurrent || isChangingPlan}
                  className={`w-full py-2 rounded-lg text-white text-sm font-semibold transition flex items-center justify-center gap-1.5 ${
                    isCurrent
                      ? 'bg-dark-600 text-dark-400 cursor-default'
                      : isFree
                      ? 'bg-green-600 hover:bg-green-500'
                      : 'bg-primary-600 hover:bg-primary-500'
                  } disabled:opacity-50`}
                  style={{
                    boxShadow: !isCurrent && !isChangingPlan
                      ? isFree
                        ? '0 10px 25px -5px rgba(34, 197, 94, 0.3)'
                        : '0 10px 25px -5px rgba(99, 102, 241, 0.3)'
                      : 'none'
                  }}
                >
                  {isChanging && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  {isCurrent ? 'Plan actuel' : isChanging ? 'Changement...' : plan.cta_label || 'Choisir ce plan'}
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* COMPARAISON DES FONCTIONNALITÉS */}
      {allFeatureLabels.length > 0 && (
        <div
          className="rounded-xl border overflow-hidden"
          style={{
            background: '#1e293b',
            borderColor: '#334155'
          }}
        >
          <div className="p-4 border-b" style={{ borderColor: '#334155' }}>
            <h3 className="font-semibold text-sm text-white">Comparaison des fonctionnalités</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b" style={{ borderColor: '#334155' }}>
                  <th className="px-4 py-3 text-left text-xs" style={{ color: '#94a3b8' }}>Fonctionnalité</th>
                  {plans.map((plan) => (
                    <th key={plan.code} className="px-4 py-3 text-center text-xs" style={{ color: '#94a3b8' }}>
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {featureCategories.map((category) => {
                  const features = allFeatureLabels.filter((label) => featureCategoryOf(label) === category.id)
                  if (features.length === 0) return null

                  return (
                    <React.Fragment key={category.id}>
                      <tr className="border-b" style={{ borderColor: '#334155' }}>
                        <td colSpan={1 + plans.length} className="px-4 py-2 text-xs font-semibold" style={{ color: '#818cf8' }}>
                          <category.icon className="w-3 h-3 inline mr-1" />
                          {category.label}
                        </td>
                      </tr>
                      {features.map((label) => {
                        const isRegistryFeature = registryLabels.includes(label)
                        return (
                          <tr key={label} className="border-b" style={{ borderColor: '#334155' }}>
                            <td className="px-4 py-2 text-xs" style={{ color: '#94a3b8' }}>{label}</td>
                            {plans.map((plan) => {
                              const entry = plan.features.find((f) => f.label === label)
                              // Fonctionnalite du registre : modele deny-list
                              // (absente du plan = incluse par defaut, voir
                              // PlanFeaturePermission cote backend).
                              // Fonctionnalite decorative libre : allow-list.
                              const hasFeature = isRegistryFeature
                                ? (entry ? entry.included : true)
                                : Boolean(entry?.included)
                              return (
                                <td key={`${plan.code}-${label}`} className="px-4 py-2 text-center">
                                  {hasFeature ? (
                                    <Check className="w-4 h-4 mx-auto" style={{ color: '#22c55e' }} />
                                  ) : (
                                    <X className="w-4 h-4 mx-auto" style={{ color: '#475569' }} />
                                  )}
                                </td>
                              )
                            })}
                          </tr>
                        )
                      })}
                    </React.Fragment>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* FACTURATION & HISTORIQUE */}
      <div
        className="rounded-xl border overflow-hidden"
        style={{ background: '#1e293b', borderColor: '#334155' }}
      >
        <div className="p-4 border-b flex items-center gap-3" style={{ borderColor: '#334155' }}>
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
            style={{ background: 'rgba(99, 102, 241, 0.15)' }}
          >
            <Receipt className="w-5 h-5" style={{ color: '#818cf8' }} />
          </div>
          <div>
            <p className="text-sm font-medium text-white">Facturation & historique</p>
            <p className="text-xs" style={{ color: '#94a3b8' }}>
              Paiement sécurisé via Airtel Money, Moov Money ou Visa/Mastercard.
            </p>
          </div>
        </div>

        {transactions.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-sm" style={{ color: '#64748b' }}>Aucun paiement d'abonnement pour le moment.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b" style={{ borderColor: '#334155' }}>
                  <th className="px-4 py-2.5 text-left text-xs" style={{ color: '#94a3b8' }}>Date</th>
                  <th className="px-4 py-2.5 text-left text-xs" style={{ color: '#94a3b8' }}>Plan</th>
                  <th className="px-4 py-2.5 text-left text-xs" style={{ color: '#94a3b8' }}>Cycle</th>
                  <th className="px-4 py-2.5 text-left text-xs" style={{ color: '#94a3b8' }}>Méthode</th>
                  <th className="px-4 py-2.5 text-right text-xs" style={{ color: '#94a3b8' }}>Montant</th>
                  <th className="px-4 py-2.5 text-left text-xs" style={{ color: '#94a3b8' }}>Statut</th>
                  <th className="px-4 py-2.5 text-right text-xs" style={{ color: '#94a3b8' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => {
                  const statusStyle: Record<PvitTransaction['status'], { label: string; color: string }> = {
                    success: { label: 'Réussi', color: '#22c55e' },
                    pending: { label: 'En attente', color: '#f59e0b' },
                    failed: { label: 'Échoué', color: '#ef4444' },
                    ambiguous: { label: 'Incertain', color: '#94a3b8' },
                  }
                  const st = statusStyle[tx.status]
                  return (
                    <tr key={tx.merchant_reference} className="border-b" style={{ borderColor: '#334155' }}>
                      <td className="px-4 py-2.5 text-xs" style={{ color: '#94a3b8' }}>
                        {new Date(tx.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </td>
                      <td className="px-4 py-2.5 text-xs text-white">{tx.plan_name}</td>
                      <td className="px-4 py-2.5 text-xs" style={{ color: '#94a3b8' }}>
                        {tx.billing_period === 'yearly' ? 'Annuel' : 'Mensuel'}
                      </td>
                      <td className="px-4 py-2.5 text-xs" style={{ color: '#94a3b8' }}>{tx.method_display}</td>
                      <td className="px-4 py-2.5 text-xs text-white text-right">
                        {Number(tx.amount).toLocaleString('fr-FR')} FCFA
                      </td>
                      <td className="px-4 py-2.5">
                        <span
                          className="text-xs px-2 py-0.5 rounded-full"
                          style={{ background: `${st.color}20`, color: st.color }}
                        >
                          {st.label}
                        </span>
                      </td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center justify-end gap-1.5">
                          {tx.status === 'success' && (
                            <button
                              onClick={() => handleDownloadInvoice(tx)}
                              disabled={downloadingRef === tx.merchant_reference}
                              className="p-1.5 rounded transition hover:bg-white/10 disabled:opacity-50"
                              style={{ color: '#818cf8' }}
                              title="Télécharger la facture"
                            >
                              {downloadingRef === tx.merchant_reference
                                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                : <Download className="w-3.5 h-3.5" />}
                            </button>
                          )}
                          {tx.status !== 'pending' && (
                            <button
                              onClick={() => handleHideTransaction(tx)}
                              disabled={hidingRef === tx.merchant_reference}
                              className="p-1.5 rounded transition hover:bg-red-500/10 disabled:opacity-50"
                              style={{ color: '#ef4444' }}
                              title="Retirer de l'historique"
                            >
                              {hidingRef === tx.merchant_reference
                                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                : <Trash2 className="w-3.5 h-3.5" />}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* SUPPORT */}
      <div
        className="rounded-xl border p-4"
        style={{
          background: '#1e293b',
          borderColor: '#334155'
        }}
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ background: 'rgba(99, 102, 241, 0.15)' }}
            >
              <Headphones className="w-5 h-5" style={{ color: '#818cf8' }} />
            </div>
            <div>
              <p className="text-sm font-medium text-white">Besoin d'aide ?</p>
              <p className="text-xs" style={{ color: '#94a3b8' }}>
                Contactez notre support pour toute question sur votre abonnement
              </p>
            </div>
          </div>
          <button
            className="px-4 py-2 rounded-lg text-white text-sm font-semibold transition flex items-center gap-2"
            style={{
              background: 'rgba(99, 102, 241, 0.15)',
              border: '1px solid rgba(99, 102, 241, 0.2)',
              color: '#818cf8'
            }}
          >
            Contacter le support
          </button>
        </div>
      </div>

      {paymentModalPlan && (
        <PvitPaymentModal
          plan={paymentModalPlan}
          billingPeriod={billingPeriod === 'yearly' && paymentModalPlan.yearly_price !== null ? 'yearly' : 'monthly'}
          onClose={() => setPaymentModalPlan(null)}
          onSuccess={() => {
            if (paymentModalPlan.certification_requirement === 'warning' && !isCertified) {
              toast.warning(
                `Le plan ${paymentModalPlan.name} recommande une entreprise certifiée. Faites certifier votre établissement.`,
                { action: { label: 'Certifier mon établissement', onClick: () => router.push('/certification') } },
              )
            }
            setPaymentModalPlan(null)
            loadData()
          }}
        />
      )}

      {showCancelModal && (
        <CancelSubscriptionModal
          hasTrialed={Boolean(subscription?.has_trialed)}
          isSubmitting={isCanceling}
          onClose={() => setShowCancelModal(false)}
          onConfirm={handleCancelSubscription}
        />
      )}
    </div>
  )
}
